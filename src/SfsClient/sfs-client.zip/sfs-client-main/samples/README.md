# Samples

This folder contains a few samples that show how to use the SFS Client library.

## integration-do-client

This sample shows how to use the SFSClient to retrieva metadata and URLs from the SFS Service and the [Delivery Optimization SDK](https://github.com/microsoft/do-client) to perform the download of the retrieved URLs.

In Windows, the DO SDK uses COM APIs. In Linux, it will require the DO Agent, which is built from the same repository.
